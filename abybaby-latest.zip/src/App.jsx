import { useState } from "react";
import { motion } from "motion/react";
// import type { Page, NavigateFn } from "./types";
import { DesktopSidebar } from "./app/components/DesktopSidebar";
import { FloatingNav } from "./app/components/FloatingNav";
import { HomePage } from "./app/components/pages/HomePage";
import { AboutPage } from "./app/components/pages/AboutPage";
import { GalleryPage } from "./app/components/pages/GalleryPage";
import { FestivalPage } from "./app/components/pages/FestivalPage";
import { BlogPage } from "./app/components/pages/BlogPage";
import { AchievementsModal } from "./app/components/ui/AchievementsModal";
import { ClientsCarousel } from "./app/components/ui/Clientscarousel";
// type PageComponent = React.ComponentType<{ navigate: NavigateFn; currentPage: Page }>;

const PAGES = {
  home: HomePage,
  about: AboutPage,
  gallery: GalleryPage,
  festival: FestivalPage,
  blog: BlogPage,
};

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const navigate = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0 });
  };

  const PageComponent = PAGES[currentPage];
  const sidebarWidth = sidebarCollapsed ? 88 : 240;

  return (
    <div className="bg-background text-foreground min-h-screen">
      <style>{`...`}</style>
      {/* Achievement modal — auto-shows 600ms after mount */}
      <AchievementsModal onExplore={() => navigate("gallery")} />
      <DesktopSidebar
        currentPage={currentPage}
        navigate={navigate}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
      />
      <ClientsCarousel />

      {/* Animate margin-left in sync with sidebar */}
      <main
        className="min-h-screen hidden lg:block"
        style={{
          marginLeft: `${sidebarWidth}px`,
          transition: "margin-left 300ms cubic-bezier(0.4,0,0.2,1)",
        }}
      >
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <PageComponent
            navigate={navigate}
            currentPage={currentPage}
            sidebarWidth={sidebarWidth}
          />
        </motion.div>
      </main>

      {/* Mobile — no sidebar offset */}
      <main className="min-h-screen lg:hidden">
        <motion.div
          key={currentPage + "-mobile"}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          <PageComponent
            navigate={navigate}
            currentPage={currentPage}
            sidebarWidth={0}
          />
        </motion.div>
      </main>

      <FloatingNav currentPage={currentPage} navigate={navigate} />
    </div>
  );
}
// import { useState } from "react";
// import { motion } from "motion/react";
// import { DesktopSidebar } from "./app/components/DesktopSidebar";
// import { FloatingNav } from "./app/components/FloatingNav";
// import { HomePage } from "./app/components/pages/HomePage";
// import { AboutPage } from "./app/components/pages/AboutPage";
// import { GalleryPage } from "./app/components/pages/GalleryPage";
// import { FestivalPage } from "./app/components/pages/FestivalPage";
// import { BlogPage } from "./app/components/pages/BlogPage";

// const PAGES = {
//   home: HomePage,
//   about: AboutPage,
//   gallery: GalleryPage,
//   festival: FestivalPage,
//   blog: BlogPage,
// };

// export default function App() {
//   const [currentPage, setCurrentPage] = useState("home");
//   const navigate = (page) => {
//     setCurrentPage(page);
//     window.scrollTo({ top: 0 });
//   };
//   const PageComponent = PAGES[currentPage];
//   return (
//     <div className="bg-background text-foreground min-h-screen">
//       <style>{`
//         body { font-family: 'DM Sans', sans-serif; }
//         .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
//         .scrollbar-hide::-webkit-scrollbar { display: none; }
//         ::-webkit-scrollbar { width: 3px; }
//         ::-webkit-scrollbar-track { background: #080808; }
//         ::-webkit-scrollbar-thumb { background: #a3e635; border-radius: 0; }
//         * { scrollbar-width: thin; scrollbar-color: #a3e635 #080808; }
//       `}</style>
//       {/* Fixed sidebar — desktop/tablet */}
//       <DesktopSidebar currentPage={currentPage} navigate={navigate} />
//       {/* Main content area — offset for sidebar on lg+ */}
//       <main className="lg:ml-[240px] min-h-screen">
//         <motion.div
//           key={currentPage}
//           initial={{ opacity: 0, y: 8 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] }}
//         >
//           <PageComponent navigate={navigate} currentPage={currentPage} />
//         </motion.div>
//       </main>
//       {/* Floating hamburger nav — mobile only */}
//       <FloatingNav currentPage={currentPage} navigate={navigate} />
//     </div>
//   );
// }

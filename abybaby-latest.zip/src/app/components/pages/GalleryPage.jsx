// import { useState } from "react";
// import { motion } from "motion/react";
// import { X, Play, Grid, Layers } from "lucide-react";
// import { StoriesBar } from "../StoriesBar";
// import { QuickNav } from "../QuickNav";
// // import type { Page, NavigateFn, Story } from "../../types";

// const STORIES = [
//   {
//     id: "g1",
//     name: "Highlights",
//     thumb:
//       "https://images.unsplash.com/photo-1562649268-bd8fa4cf7ad7?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g2",
//     name: "Lanterns",
//     thumb:
//       "https://images.unsplash.com/photo-1580558036732-53b6b3574160?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g3",
//     name: "Performers",
//     thumb:
//       "https://images.unsplash.com/photo-1585371843734-1800eada9acc?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g4",
//     name: "Decor",
//     thumb:
//       "https://images.unsplash.com/photo-1600400411727-6f0fd6e10933?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g5",
//     name: "Nightlife",
//     thumb:
//       "https://images.unsplash.com/photo-1757598078141-991920b9339a?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g6",
//     name: "Crowds",
//     thumb:
//       "https://images.unsplash.com/photo-1616787671779-eed71117a65e?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g7",
//     name: "Concerts",
//     thumb:
//       "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=200&h=200&fit=crop&auto=format",
//   },
//   {
//     id: "g8",
//     name: "Summits",
//     thumb:
//       "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=200&h=200&fit=crop&auto=format",
//   },
// ];

// // interface GalleryItem {
// //   id: string;
// //   url: string;
// //   alt: string;
// //   caption: string;
// //   isVideo?: boolean;
// // }

// const ITEMS = [
//   {
//     id: "gi1",
//     url: "https://images.unsplash.com/photo-1562649268-bd8fa4cf7ad7?w=600&h=600&fit=crop&auto=format",
//     alt: "Stage event",
//     caption: "National Product Launch",
//     isVideo: true,
//   },
//   {
//     id: "gi2",
//     url: "https://images.unsplash.com/photo-1580558036732-53b6b3574160?w=600&h=600&fit=crop&auto=format",
//     alt: "Lanterns",
//     caption: "Diwali Activation",
//   },
//   {
//     id: "gi3",
//     url: "https://images.unsplash.com/photo-1585371843734-1800eada9acc?w=600&h=600&fit=crop&auto=format",
//     alt: "Dancers",
//     caption: "Cultural Fest Mumbai",
//     isVideo: true,
//   },
//   {
//     id: "gi4",
//     url: "https://images.unsplash.com/photo-1600400411727-6f0fd6e10933?w=600&h=600&fit=crop&auto=format",
//     alt: "Decor",
//     caption: "Premium Gala Decor",
//   },
//   {
//     id: "gi5",
//     url: "https://images.unsplash.com/photo-1757598078141-991920b9339a?w=600&h=600&fit=crop&auto=format",
//     alt: "Night event",
//     caption: "Corporate Night Out",
//     isVideo: true,
//   },
//   {
//     id: "gi6",
//     url: "https://images.unsplash.com/photo-1646929189708-eb1b9fff7387?w=600&h=600&fit=crop&auto=format",
//     alt: "Crowd",
//     caption: "Retail Brand Activation",
//   },
//   {
//     id: "gi7",
//     url: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&h=600&fit=crop&auto=format",
//     alt: "Concert",
//     caption: "Music Festival 2024",
//     isVideo: true,
//   },
//   {
//     id: "gi8",
//     url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=600&fit=crop&auto=format",
//     alt: "Conference",
//     caption: "National Summit 2024",
//   },
//   {
//     id: "gi9",
//     url: "https://images.unsplash.com/photo-1616787671779-eed71117a65e?w=600&h=600&fit=crop&auto=format",
//     alt: "Crowd hands",
//     caption: "Republic Day Rally",
//     isVideo: true,
//   },
//   {
//     id: "gi10",
//     url: "https://images.unsplash.com/photo-1738151466731-7d98e3fe6b3c?w=600&h=600&fit=crop&auto=format",
//     alt: "Stage speaker",
//     caption: "Leadership Summit",
//   },
//   {
//     id: "gi11",
//     url: "https://images.unsplash.com/photo-1573964093819-aaa848e41d4a?w=600&h=600&fit=crop&auto=format",
//     alt: "Divine statues",
//     caption: "Navratri Cultural Fair",
//   },
//   {
//     id: "gi12",
//     url: "https://images.unsplash.com/photo-1772947314926-a3bcffd09b1b?w=600&h=600&fit=crop&auto=format",
//     alt: "Fire ritual",
//     caption: "Traditional Fire Festival",
//   },
// ];

// // interface GalleryPageProps {
// //   navigate: NavigateFn;
// //   currentPage: Page;
// // }

// export function GalleryPage({ navigate, currentPage }) {
//   const [lightboxIdx, setLightboxIdx] = useState(null);
//   const [closingLb, setClosingLb] = useState(false);
//   const [view, setView] = useState("grid");

//   const openLightbox = (idx) => setLightboxIdx(idx);

//   const closeLightbox = () => {
//     setClosingLb(true);
//     setTimeout(() => {
//       setLightboxIdx(null);
//       setClosingLb(false);
//     }, 180);
//   };

//   const lbNext = () =>
//     setLightboxIdx((i) => (i !== null && i < ITEMS.length - 1 ? i + 1 : i));
//   const lbPrev = () => setLightboxIdx((i) => (i !== null && i > 0 ? i - 1 : i));

//   return (
//     <div className="min-h-screen bg-background">
//       {/* Mobile header */}
//       <div
//         className="lg:hidden sticky top-0 z-30 bg-card/96 backdrop-blur-sm border-b border-border px-5 h-14 flex items-center justify-between"
//         onClick={() => navigate("home")}
//       >
//         <div
//           style={{ fontFamily: "'Cinzel', serif" }}
//           className="text-lg font-bold text-primary"
//         >
//           AbyBaby
//           <span className="text-foreground/65 ml-1 text-base">Group</span>
//         </div>
//         <div className="flex gap-2">
//           <button
//             onClick={() => setView("grid")}
//             className={
//               view === "grid" ? "text-primary" : "text-muted-foreground"
//             }
//           >
//             <Grid size={18} />
//           </button>
//           <button
//             onClick={() => setView("columns")}
//             className={
//               view === "columns" ? "text-primary" : "text-muted-foreground"
//             }
//           >
//             <Layers size={18} />
//           </button>
//         </div>
//       </div>

//       {/* Stories */}
//       <StoriesBar stories={STORIES} pageLabel="Gallery Reels" />

//       {/* Grid heading */}
//       <div className="max-w-[740px] mx-auto px-5 pt-5 pb-3 flex items-center justify-between">
//         <div>
//           <h2
//             style={{ fontFamily: "'Cinzel', serif" }}
//             className="text-lg font-bold text-foreground"
//           >
//             Our <span className="text-primary">Portfolio</span>
//           </h2>
//           <p className="text-xs text-muted-foreground mt-0.5">
//             {ITEMS.length} captured moments
//           </p>
//         </div>
//         <div className="hidden lg:flex gap-2">
//           <button
//             onClick={() => setView("grid")}
//             className={`p-2 rounded-lg border ${view === "grid" ? "border-primary text-primary" : "border-border text-muted-foreground"}`}
//           >
//             <Grid size={16} />
//           </button>
//           <button
//             onClick={() => setView("columns")}
//             className={`p-2 rounded-lg border ${view === "columns" ? "border-primary text-primary" : "border-border text-muted-foreground"}`}
//           >
//             <Layers size={16} />
//           </button>
//         </div>
//       </div>

//       {/* Photo grid */}
//       <div
//         className={`max-w-[740px] mx-auto border-b border-border ${view === "grid" ? "grid grid-cols-3 gap-px bg-border" : "columns-2 gap-2 px-1"}`}
//       >
//         {ITEMS.map((item, i) => (
//           <motion.button
//             key={item.id}
//             onClick={() => openLightbox(i)}
//             className={`relative bg-muted overflow-hidden ${view === "grid" ? "aspect-square" : "break-inside-avoid mb-2 block"}`}
//             initial={{ opacity: 0 }}
//             whileInView={{ opacity: 1 }}
//             viewport={{ once: true }}
//             transition={{ duration: 0.35, delay: i * 0.04 }}
//             whileTap={{ scale: 0.97 }}
//           >
//             <img
//               src={item.url}
//               alt={item.alt}
//               className={`w-full object-cover hover:scale-105 transition-transform duration-500 ${view === "grid" ? "h-full" : "h-auto"}`}
//               loading="lazy"
//             />
//             {item.isVideo && (
//               <div className="absolute top-2 right-2">
//                 <Play size={14} className="text-white fill-white drop-shadow" />
//               </div>
//             )}
//           </motion.button>
//         ))}
//       </div>

//       {/* <div className="max-w-[740px] mx-auto">
//         <QuickNav currentPage={currentPage} navigate={navigate} />
//       </div> */}

//       {/* Lightbox */}
//       {lightboxIdx !== null && (
//         <motion.div
//           className="fixed inset-0 z-[200] bg-black/96 flex items-center justify-center"
//           animate={{ opacity: closingLb ? 0 : 1 }}
//           initial={{ opacity: 0 }}
//           transition={{ duration: 0.18 }}
//           onClick={closeLightbox}
//         >
//           <button
//             onClick={closeLightbox}
//             className="absolute top-4 right-4 z-10 text-white/80 hover:text-white"
//           >
//             <X size={28} />
//           </button>

//           <div
//             className="relative max-w-[90vw] max-h-[85vh]"
//             onClick={(e) => e.stopPropagation()}
//           >
//             <img
//               src={ITEMS[lightboxIdx].url.replace("600&h=600", "1000&h=1000")}
//               alt={ITEMS[lightboxIdx].alt}
//               className="max-w-full max-h-[80vh] object-contain"
//             />
//             <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent py-4 px-5">
//               <p
//                 style={{ fontFamily: "'Cinzel', serif" }}
//                 className="text-white font-semibold"
//               >
//                 {ITEMS[lightboxIdx].caption}
//               </p>
//             </div>
//           </div>

//           <button
//             className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-primary/80 transition-colors"
//             onClick={(e) => {
//               e.stopPropagation();
//               lbPrev();
//             }}
//           >
//             ‹
//           </button>
//           <button
//             className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-primary/80 transition-colors"
//             onClick={(e) => {
//               e.stopPropagation();
//               lbNext();
//             }}
//           >
//             ›
//           </button>
//         </motion.div>
//       )}
//     </div>
//   );
// }
import { useState, useRef } from "react";
import { motion, useInView } from "motion/react";
import { X, Play, Grid, Layers } from "lucide-react";
import { StoriesBar } from "../StoriesBar";
import { QuickNav } from "../QuickNav";

const STORIES = [
  {
    id: "g1",
    name: "Highlights",
    thumb:
      "https://images.unsplash.com/photo-1562649268-bd8fa4cf7ad7?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g2",
    name: "Lanterns",
    thumb:
      "https://images.unsplash.com/photo-1580558036732-53b6b3574160?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g3",
    name: "Performers",
    thumb:
      "https://images.unsplash.com/photo-1585371843734-1800eada9acc?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g4",
    name: "Decor",
    thumb:
      "https://images.unsplash.com/photo-1600400411727-6f0fd6e10933?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g5",
    name: "Nightlife",
    thumb:
      "https://images.unsplash.com/photo-1757598078141-991920b9339a?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g6",
    name: "Crowds",
    thumb:
      "https://images.unsplash.com/photo-1616787671779-eed71117a65e?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g7",
    name: "Concerts",
    thumb:
      "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=200&h=200&fit=crop&auto=format",
  },
  {
    id: "g8",
    name: "Summits",
    thumb:
      "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=200&h=200&fit=crop&auto=format",
  },
];

const ITEMS = [
  {
    id: "gi1",
    url: "https://images.unsplash.com/photo-1562649268-bd8fa4cf7ad7?w=600&h=600&fit=crop&auto=format",
    alt: "Stage event",
    caption: "National Product Launch",
    isVideo: true,
  },
  {
    id: "gi2",
    url: "https://images.unsplash.com/photo-1580558036732-53b6b3574160?w=600&h=600&fit=crop&auto=format",
    alt: "Lanterns",
    caption: "Diwali Activation",
  },
  {
    id: "gi3",
    url: "https://images.unsplash.com/photo-1585371843734-1800eada9acc?w=600&h=600&fit=crop&auto=format",
    alt: "Dancers",
    caption: "Cultural Fest Mumbai",
    isVideo: true,
  },
  {
    id: "gi4",
    url: "https://images.unsplash.com/photo-1600400411727-6f0fd6e10933?w=600&h=600&fit=crop&auto=format",
    alt: "Decor",
    caption: "Premium Gala Decor",
  },
  {
    id: "gi5",
    url: "https://images.unsplash.com/photo-1757598078141-991920b9339a?w=600&h=600&fit=crop&auto=format",
    alt: "Night event",
    caption: "Corporate Night Out",
    isVideo: true,
  },
  {
    id: "gi6",
    url: "https://images.unsplash.com/photo-1646929189708-eb1b9fff7387?w=600&h=600&fit=crop&auto=format",
    alt: "Crowd",
    caption: "Retail Brand Activation",
  },
  {
    id: "gi7",
    url: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&h=600&fit=crop&auto=format",
    alt: "Concert",
    caption: "Music Festival 2024",
    isVideo: true,
  },
  {
    id: "gi8",
    url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=600&fit=crop&auto=format",
    alt: "Conference",
    caption: "National Summit 2024",
  },
  {
    id: "gi9",
    url: "https://images.unsplash.com/photo-1616787671779-eed71117a65e?w=600&h=600&fit=crop&auto=format",
    alt: "Crowd hands",
    caption: "Republic Day Rally",
    isVideo: true,
  },
  {
    id: "gi10",
    url: "https://images.unsplash.com/photo-1738151466731-7d98e3fe6b3c?w=600&h=600&fit=crop&auto=format",
    alt: "Stage speaker",
    caption: "Leadership Summit",
  },
  {
    id: "gi11",
    url: "https://images.unsplash.com/photo-1573964093819-aaa848e41d4a?w=600&h=600&fit=crop&auto=format",
    alt: "Divine statues",
    caption: "Navratri Cultural Fair",
  },
  {
    id: "gi12",
    url: "https://images.unsplash.com/photo-1772947314926-a3bcffd09b1b?w=600&h=600&fit=crop&auto=format",
    alt: "Fire ritual",
    caption: "Traditional Fire Festival",
  },
];

function TranslateYCard({ item, index, view, onClick }) {
  const ref = useRef(null);

  const isInView = useInView(ref, {
    once: true,
    margin: "0px 0px -80px 0px",
  });

  return (
    <motion.button
      ref={ref}
      onClick={onClick}
      initial={{
        opacity: 0,
        y: 80,
      }}
      animate={
        isInView
          ? {
              opacity: 1,
              y: 0,
            }
          : {}
      }
      transition={{
        duration: 0.7,
        delay: index * 0.06,
        ease: [0.22, 1, 0.36, 1],
      }}
      whileTap={{ scale: 0.97 }}
      className={`relative overflow-hidden bg-muted ${
        view === "grid"
          ? "aspect-square"
          : "break-inside-avoid mb-2 block w-full"
      }`}
    >
      <img
        src={item.url}
        alt={item.alt}
        loading="lazy"
        className={`w-full object-cover ${
          view === "grid" ? "h-full" : "h-auto"
        }`}
      />

      {item.isVideo && (
        <div className="absolute top-2 right-2">
          <Play size={14} className="text-white fill-white drop-shadow" />
        </div>
      )}
    </motion.button>
  );
}

export function GalleryPage({ navigate, currentPage, sidebarWidth = 240 }) {
  const [lightboxIdx, setLightboxIdx] = useState(null);
  const [closingLb, setClosingLb] = useState(false);
  const [view, setView] = useState("grid");

  const openLightbox = (idx) => setLightboxIdx(idx);

  const closeLightbox = () => {
    setClosingLb(true);

    setTimeout(() => {
      setLightboxIdx(null);
      setClosingLb(false);
    }, 180);
  };

  const lbNext = () =>
    setLightboxIdx((i) => (i !== null && i < ITEMS.length - 1 ? i + 1 : i));

  const lbPrev = () => setLightboxIdx((i) => (i !== null && i > 0 ? i - 1 : i));

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <div
        className="lg:hidden sticky top-0 z-30 bg-card/96 backdrop-blur-sm border-b border-border px-5 h-14 flex items-center justify-between"
        onClick={() => navigate("home")}
      >
        <div
          style={{ fontFamily: "'Cinzel', serif" }}
          className="text-lg font-bold text-primary"
        >
          AbyBaby
          <span className="text-foreground/65 ml-1 text-base">Group</span>
        </div>

        <div className="flex gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setView("grid");
            }}
            className={
              view === "grid" ? "text-primary" : "text-muted-foreground"
            }
          >
            <Grid size={18} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              setView("columns");
            }}
            className={
              view === "columns" ? "text-primary" : "text-muted-foreground"
            }
          >
            <Layers size={18} />
          </button>
        </div>
      </div>

      {/* Stories */}
      <StoriesBar
        stories={STORIES}
        pageLabel="Gallery Reels"
        sidebarWidth={sidebarWidth}
      />

      {/* Heading */}
      <div className="max-w-[740px] mx-auto px-5 pt-5 pb-3 flex items-center justify-between">
        <div>
          <h2
            style={{ fontFamily: "'Cinzel', serif" }}
            className="text-lg font-bold text-foreground"
          >
            Our <span className="text-primary">Portfolio</span>
          </h2>

          <p className="text-xs text-muted-foreground mt-0.5">
            {ITEMS.length} captured moments
          </p>
        </div>

        <div className="hidden lg:flex gap-2">
          <button
            onClick={() => setView("grid")}
            className={`p-2 rounded-lg border ${
              view === "grid"
                ? "border-primary text-primary"
                : "border-border text-muted-foreground"
            }`}
          >
            <Grid size={16} />
          </button>

          <button
            onClick={() => setView("columns")}
            className={`p-2 rounded-lg border ${
              view === "columns"
                ? "border-primary text-primary"
                : "border-border text-muted-foreground"
            }`}
          >
            <Layers size={16} />
          </button>
        </div>
      </div>

      {/* Gallery */}
      <div
        className={`max-w-[740px] mx-auto border-b border-border ${
          view === "grid"
            ? "grid grid-cols-3 gap-px bg-border"
            : "columns-2 gap-2 px-1"
        }`}
      >
        {ITEMS.map((item, i) => (
          <TranslateYCard
            key={item.id}
            item={item}
            index={i}
            view={view}
            onClick={() => openLightbox(i)}
          />
        ))}
      </div>

      {/* Quick Nav */}
      {/* <div className="max-w-[740px] mx-auto">
        <QuickNav
          currentPage={currentPage}
          navigate={navigate}
        />
      </div> */}

      {/* Lightbox */}
      {lightboxIdx !== null && (
        <motion.div
          className="fixed inset-0 z-[200] bg-black/96 flex items-center justify-center"
          animate={{ opacity: closingLb ? 0 : 1 }}
          initial={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 z-10 text-white/80 hover:text-white"
          >
            <X size={28} />
          </button>

          <div
            className="relative max-w-[90vw] max-h-[85vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={ITEMS[lightboxIdx].url.replace("600&h=600", "1000&h=1000")}
              alt={ITEMS[lightboxIdx].alt}
              className="max-w-full max-h-[80vh] object-contain"
            />

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent py-4 px-5">
              <p
                style={{ fontFamily: "'Cinzel', serif" }}
                className="text-white font-semibold"
              >
                {ITEMS[lightboxIdx].caption}
              </p>
            </div>
          </div>

          <button
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-primary/80 transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              lbPrev();
            }}
          >
            ‹
          </button>

          <button
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-primary/80 transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              lbNext();
            }}
          >
            ›
          </button>
        </motion.div>
      )}
    </div>
  );
}

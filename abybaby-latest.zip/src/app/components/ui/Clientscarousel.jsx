import { useEffect, useRef } from "react";

const CLIENTS = [
  { id: 1, name: "Adobe", initials: "Ad" },
  { id: 2, name: "Spotify", initials: "Sp" },
  { id: 3, name: "Figma", initials: "Fi" },
  { id: 4, name: "Notion", initials: "No" },
  { id: 5, name: "Slack", initials: "Sl" },
  { id: 6, name: "Stripe", initials: "St" },
  { id: 7, name: "Vercel", initials: "Ve" },
  { id: 8, name: "Linear", initials: "Li" },
  { id: 9, name: "Loom", initials: "Lo" },
  { id: 10, name: "Webflow", initials: "Wf" },
  { id: 11, name: "Framer", initials: "Fr" },
  { id: 12, name: "Miro", initials: "Mi" },
];

// Triple the list — first copy scrolls away, second is visible, third ensures no gap at reset
const TRIPLED = [...CLIENTS, ...CLIENTS, ...CLIENTS];

function ClientCard({ client }) {
  return (
    <div
      className="cc-card"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "8px",
        padding: "10px 0",
        width: "100%",
        boxSizing: "border-box",
        cursor: "default",
        userSelect: "none",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.querySelector(".cc-initials").style.background =
          "rgba(255,255,255,0.3)";
        e.currentTarget.querySelector(".cc-initials").style.borderColor =
          "rgba(255,255,255,0.8)";
        e.currentTarget.querySelector(".cc-initials").style.color = "#ffffff";
        e.currentTarget.querySelector(".cc-name").style.color = "#ffffff";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.querySelector(".cc-initials").style.background =
          "rgba(255,255,255,0.15)";
        e.currentTarget.querySelector(".cc-initials").style.borderColor =
          "rgba(255,255,255,0.3)";
        e.currentTarget.querySelector(".cc-initials").style.color = "#ffffff";
        e.currentTarget.querySelector(".cc-name").style.color =
          "rgba(255,255,255,0.75)";
      }}
    >
      {/* Initials avatar — stays upright */}

      {/* Name rotated 90° anticlockwise */}
      <span
        className="cc-name"
        style={{
          fontSize: "11px",
          fontWeight: 600,
          color: "rgba(255,255,255,0.75)",
          letterSpacing: "0.4px",
          whiteSpace: "nowrap",
          transition: "color 180ms",
          display: "block",
          transform: "rotate(-90deg)",
          transformOrigin: "center center",
        }}
      >
        {client.name}
      </span>
    </div>
  );
}

export function ClientsCarousel() {
  const trackRef = useRef(null);
  const pausedRef = useRef(false);
  const animRef = useRef(null);
  const posRef = useRef(0);
  const halfRef = useRef(0);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    // Wait two frames so the DOM is fully painted and scrollHeight is stable
    let raf1 = requestAnimationFrame(() => {
      let raf2 = requestAnimationFrame(() => {
        // halfRef = height of ONE set of CLIENTS (tripled list / 3)
        halfRef.current = track.scrollHeight / 3;

        const SPEED = 0.5; // px per frame — smooth & readable

        const tick = () => {
          if (!pausedRef.current) {
            posRef.current += SPEED;
            // When we've scrolled exactly one full set, snap back silently
            if (posRef.current >= halfRef.current) {
              posRef.current -= halfRef.current; // subtract, don't reset to 0 — prevents jump
            }
            track.style.transform = `translateY(-${posRef.current}px)`;
          }
          animRef.current = requestAnimationFrame(tick);
        };

        animRef.current = requestAnimationFrame(tick);
      });
    });

    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(animRef.current);
    };
  }, []);

  return (
    <>
      <style>{`
        .cc-rail {
          position: fixed;
          top: 0;
          right: 0;
          width: 72px;
          height: 100vh;
          z-index: 40;
          display: flex;
          flex-direction: column;
          align-items: stretch;
          overflow: hidden;
          background: linear-gradient(to bottom right, #4d7c0f, var(--primary));
          border-left: 1px solid rgba(163, 230, 53, 0.25);
          -webkit-mask-image: linear-gradient(
            to bottom,
            transparent 0%,
            black 9%,
            black 91%,
            transparent 100%
          );
          mask-image: linear-gradient(
            to bottom,
            transparent 0%,
            black 9%,
            black 91%,
            transparent 100%
          );
        }

        .cc-header {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          z-index: 3;
          padding: 18px 14px 10px;
          pointer-events: none;
        }

        .cc-header-label {
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 1.6px;
          text-transform: uppercase;
          color: rgba(255,255,255,0.9);
          display: block;
          margin-bottom: 8px;
          text-align: center;
        }

        .cc-header-divider {
          width: 100%;
          height: 1.5px;
          background: rgba(255,255,255,0.5);
          border-radius: 2px;
        }

        @media (max-width: 1023px) {
          .cc-rail { display: none; }
        }
      `}</style>

      <div
        className="cc-rail"
        onMouseEnter={() => (pausedRef.current = true)}
        onMouseLeave={() => (pausedRef.current = false)}
      >
        <div
          ref={trackRef}
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            paddingTop: 70,
            paddingBottom: 8,
            willChange: "transform",
            gap: 8,
          }}
        >
          {TRIPLED.map((client, i) => (
            <ClientCard key={`${client.id}-${i}`} client={client} />
          ))}
        </div>
      </div>
    </>
  );
}

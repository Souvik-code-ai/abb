// import { useState, useEffect } from "react";
// import { motion } from "motion/react";
// import { X } from "lucide-react";
// // import type { Story } from "../types";

// // interface StoriesBarProps {
// //   stories: Story[];
// //   pageLabel?: string;
// // }

// export function StoriesBar({ stories, pageLabel }) {
//   const [viewerOpen, setViewerOpen] = useState(false);
//   const [activeIdx, setActiveIdx] = useState(0);
//   const [progress, setProgress] = useState(0);
//   const [closing, setClosing] = useState(false);
//   const [viewed, setViewed] = useState(new Set());
//   const openStory = (idx) => {
//     setActiveIdx(idx);
//     setProgress(0);
//     setViewerOpen(true);
//   };

//   const closeViewer = () => {
//     setClosing(true);
//     setViewed((v) => new Set([...v, stories[activeIdx].id]));
//     setTimeout(() => {
//       setViewerOpen(false);
//       setClosing(false);
//       setProgress(0);
//     }, 180);
//   };

//   const goNext = () => {
//     setViewed((v) => new Set([...v, stories[activeIdx].id]));
//     if (activeIdx < stories.length - 1) {
//       setActiveIdx((i) => i + 1);
//       setProgress(0);
//     } else {
//       closeViewer();
//     }
//   };

//   const goPrev = () => {
//     if (activeIdx > 0) {
//       setActiveIdx((i) => i - 1);
//       setProgress(0);
//     }
//   };

//   useEffect(() => {
//     if (!viewerOpen || closing) return;
//     const timer = setInterval(() => {
//       setProgress((p) => {
//         if (p >= 100) {
//           if (activeIdx < stories.length - 1) {
//             setViewed((v) => new Set([...v, stories[activeIdx].id]));
//             setActiveIdx((i) => i + 1);
//             return 0;
//           } else {
//             closeViewer();
//             return 0;
//           }
//         }
//         return p + 2.5;
//       });
//     }, 100);
//     return () => clearInterval(timer);
//   }, [viewerOpen, activeIdx, closing, stories.length]);

//   const story = stories[activeIdx];

//   return (
//     <>
//       {/* Stories Row */}
//       <div className="sticky lg:top-0 z-20 flex gap-4 overflow-x-auto scrollbar-hide px-4 py-4 border-b border-border bg-card top-14">
//         {stories.map((s, idx) => (
//           <motion.button
//             key={s.id}
//             onClick={() => openStory(idx)}
//             className="flex flex-col items-center gap-1.5 flex-shrink-0"
//             whileTap={{ scale: 0.92 }}
//           >
//             <div
//               className={`p-[2px] rounded-full ${
//                 viewed.has(s.id)
//                   ? "bg-muted"
//                   : "bg-gradient-to-tr from-green-700 via-lime-400 to-primary"
//               }`}
//             >
//               <div className="w-[58px] h-[58px] rounded-full border-2 border-background overflow-hidden bg-muted">
//                 <img
//                   src={s.thumb}
//                   alt={s.name}
//                   className="w-full h-full object-cover"
//                   loading="lazy"
//                 />
//               </div>
//             </div>
//             <span className="text-[10px] text-foreground/65 w-16 text-center truncate leading-tight">
//               {s.name}
//             </span>
//           </motion.button>
//         ))}
//       </div>

//       {/* Full-screen Story Viewer */}
//       {viewerOpen && story && (
//         <motion.div
//           className="fixed inset-0 z-[200] bg-black flex items-center justify-center"
//           animate={{ opacity: closing ? 0 : 1 }}
//           initial={{ opacity: 0 }}
//           transition={{ duration: 0.18 }}
//         >
//           <div className="relative w-full h-full max-w-[480px] overflow-hidden">
//             {/* Progress bars */}
//             <div className="absolute top-3 left-3 right-3 flex gap-1 z-20">
//               {stories.map((_, i) => (
//                 <div
//                   key={i}
//                   className="flex-1 h-[2px] bg-white/25 rounded-full overflow-hidden"
//                 >
//                   <div
//                     className="h-full bg-white rounded-full"
//                     style={{
//                       width:
//                         i < activeIdx
//                           ? "100%"
//                           : i === activeIdx
//                             ? `${progress}%`
//                             : "0%",
//                     }}
//                   />
//                 </div>
//               ))}
//             </div>

//             {/* Header */}
//             <div className="absolute top-8 left-3 right-10 flex items-center gap-2.5 z-20 ">
//               <div className="w-9 h-9 rounded-full border border-primary/60 bg-gradient-to-br from-lime-700 to-primary flex items-center justify-center flex-shrink-0">
//                 <span
//                   style={{ fontFamily: "'Cinzel', serif" }}
//                   className="text-xs font-bold text-white"
//                 >
//                   AB
//                 </span>
//               </div>
//               <div>
//                 <div
//                   style={{ fontFamily: "'Cinzel', serif" }}
//                   className="text-white text-sm font-semibold leading-tight"
//                 >
//                   AbyBaby Group
//                 </div>
//                 <div className="text-white/55 text-xs">{story.name}</div>
//               </div>
//             </div>

//             {/* Close */}
//             <button
//               onClick={closeViewer}
//               className="absolute top-8 right-3 z-20 text-white/80 hover:text-white p-1"
//             >
//               <X size={22} />
//             </button>

//             {/* Story Image */}
//             <img
//               src={`${story.thumb.split("?")[0]}?w=600&h=1060&fit=crop&auto=format`}
//               alt={story.name}
//               className="w-full h-full object-cover"
//             />

//             {/* Bottom gradient + label */}
//             <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-black/85 to-transparent pointer-events-none" />
//             <div className="absolute bottom-10 left-5 right-5 pointer-events-none">
//               <p
//                 style={{ fontFamily: "'Cinzel', serif" }}
//                 className="text-white text-xl font-bold"
//               >
//                 {story.name}
//               </p>
//               {pageLabel && (
//                 <p className="text-white/55 text-sm mt-1">{pageLabel}</p>
//               )}
//             </div>

//             {/* Tap zones */}
//             <button
//               className="absolute left-0 top-16 bottom-0 w-1/3 z-10"
//               onClick={goPrev}
//             />
//             <button
//               className="absolute right-0 top-16 bottom-0 w-2/3 z-10"
//               onClick={goNext}
//             />
//           </div>
//         </motion.div>
//       )}
//     </>
//   );
// }
import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { X } from "lucide-react";

export function StoriesBar({ stories, pageLabel, sidebarWidth = 0 }) {
  const [viewerOpen, setViewerOpen] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const [progress, setProgress] = useState(0);
  const [closing, setClosing] = useState(false);
  const [viewed, setViewed] = useState(new Set());

  const openStory = (idx) => {
    setActiveIdx(idx);
    setProgress(0);
    setViewerOpen(true);
  };

  const closeViewer = () => {
    setClosing(true);
    setViewed((v) => new Set([...v, stories[activeIdx].id]));
    setTimeout(() => {
      setViewerOpen(false);
      setClosing(false);
      setProgress(0);
    }, 180);
  };

  const goNext = () => {
    setViewed((v) => new Set([...v, stories[activeIdx].id]));
    if (activeIdx < stories.length - 1) {
      setActiveIdx((i) => i + 1);
      setProgress(0);
    } else {
      closeViewer();
    }
  };

  const goPrev = () => {
    if (activeIdx > 0) {
      setActiveIdx((i) => i - 1);
      setProgress(0);
    }
  };

  // Auto-progress timer
  useEffect(() => {
    if (!viewerOpen || closing) return;
    const timer = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          if (activeIdx < stories.length - 1) {
            setViewed((v) => new Set([...v, stories[activeIdx].id]));
            setActiveIdx((i) => i + 1);
            return 0;
          } else {
            closeViewer();
            return 0;
          }
        }
        return p + 2.5;
      });
    }, 100);
    return () => clearInterval(timer);
  }, [viewerOpen, activeIdx, closing, stories.length]);

  // Keyboard arrow navigation
  useEffect(() => {
    if (!viewerOpen) return;
    const onKey = (e) => {
      if (e.key === "ArrowRight" || e.key === ">") goNext();
      if (e.key === "ArrowLeft" || e.key === "<") goPrev();
      if (e.key === "Escape") closeViewer();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [viewerOpen, activeIdx, closing]);

  const story = stories[activeIdx];

  return (
    <>
      {/* Stories Row */}
      <div
        className="fixed lg:top-0 z-20 flex gap-4 overflow-x-auto scrollbar-hide px-4 py-4 border-b border-border bg-card top-14"
        style={{
          left: `${sidebarWidth}px`,
          right: 0,
          transition: "left 300ms cubic-bezier(0.4,0,0.2,1)",
        }}
      >
        {stories.map((s, idx) => (
          <motion.button
            key={s.id}
            onClick={() => openStory(idx)}
            className="flex flex-col items-center gap-1.5 flex-shrink-0"
            whileTap={{ scale: 0.92 }}
          >
            <div
              className={`p-[2px] rounded-full ${
                viewed.has(s.id)
                  ? "bg-muted"
                  : "bg-gradient-to-tr from-lime-600 via-lime-400 to-green-300"
              }`}
            >
              <div className="w-[58px] h-[58px] rounded-full border-2 border-background overflow-hidden bg-muted">
                <img
                  src={s.thumb}
                  alt={s.name}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            </div>
            <span className="text-[10px] text-foreground/65 w-16 text-center truncate leading-tight">
              {s.name}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Full-screen Story Viewer */}
      {viewerOpen && story && (
        <motion.div
          className="fixed inset-0 z-[200] bg-black flex items-center justify-center"
          animate={{ opacity: closing ? 0 : 1 }}
          initial={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
        >
          <div className="relative w-full h-full max-w-[480px] overflow-hidden">
            {/* Progress bars */}
            <div className="absolute top-3 left-3 right-3 flex gap-1 z-20">
              {stories.map((_, i) => (
                <div
                  key={i}
                  className="flex-1 h-[2px] bg-white/25 rounded-full overflow-hidden"
                >
                  <div
                    className="h-full bg-white rounded-full"
                    style={{
                      width:
                        i < activeIdx
                          ? "100%"
                          : i === activeIdx
                            ? `${progress}%`
                            : "0%",
                    }}
                  />
                </div>
              ))}
            </div>

            {/* Header */}
            <div className="absolute top-8 left-3 right-10 flex items-center gap-2.5 z-20">
              <div className="w-9 h-9 rounded-full border border-primary/60 bg-gradient-to-br from-lime-600 to-primary flex items-center justify-center flex-shrink-0">
                <span
                  style={{ fontFamily: "'Cinzel', serif" }}
                  className="text-xs font-bold text-white"
                >
                  AB
                </span>
              </div>
              <div>
                <div
                  style={{ fontFamily: "'Cinzel', serif" }}
                  className="text-white text-sm font-semibold leading-tight"
                >
                  AbyBaby Group
                </div>
                <div className="text-white/55 text-xs">{story.name}</div>
              </div>
            </div>

            {/* Close */}
            <button
              onClick={closeViewer}
              className="absolute top-8 right-3 z-20 text-white/80 hover:text-white p-1"
            >
              <X size={22} />
            </button>

            {/* Story Image */}
            <img
              src={`${story.thumb.split("?")[0]}?w=600&h=1060&fit=crop&auto=format`}
              alt={story.name}
              className="w-full h-full object-cover"
            />

            {/* Bottom gradient + label */}
            <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-black/85 to-transparent pointer-events-none" />
            <div className="absolute bottom-10 left-5 right-5 pointer-events-none">
              <p
                style={{ fontFamily: "'Cinzel', serif" }}
                className="text-white text-xl font-bold"
              >
                {story.name}
              </p>
              {pageLabel && (
                <p className="text-white/55 text-sm mt-1">{pageLabel}</p>
              )}
            </div>

            {/* Tap zones */}
            <button
              className="absolute left-0 top-16 bottom-0 w-1/3 z-10"
              onClick={goPrev}
            />
            <button
              className="absolute right-0 top-16 bottom-0 w-2/3 z-10"
              onClick={goNext}
            />
          </div>
        </motion.div>
      )}
    </>
  );
}

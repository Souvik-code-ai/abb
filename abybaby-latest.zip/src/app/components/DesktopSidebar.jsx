// import { Instagram, Facebook, Twitter, Youtube, Phone, Home, Info, Image, Star, BookOpen, Mail } from "lucide-react";
// import type { Page, NavigateFn } from "../types";

// const NAV_ITEMS = [
//   { id: "home" as Page, label: "Home", Icon: Home },
//   { id: "about" as Page, label: "About", Icon: Info },
//   { id: "gallery" as Page, label: "Gallery", Icon: Image },
//   { id: "festival" as Page, label: "Festival", Icon: Star },
//   { id: "blog" as Page, label: "Blog", Icon: BookOpen },
// ];

// interface SidebarProps {
//   currentPage: Page;
//   navigate: NavigateFn;
// }

// export function DesktopSidebar({ currentPage, navigate }: SidebarProps) {
//   return (
//     <aside className="hidden lg:flex fixed left-0 top-0 h-full w-[240px] bg-card border-r border-border flex-col z-40">
//       {/* Logo */}
//       <div className="px-6 py-5 border-b border-border">
//         <div
//           style={{ fontFamily: "'Cinzel', serif" }}
//           className="text-xl font-bold text-primary leading-tight"
//         >
//           AbyBaby
//           <span className="text-foreground/65 ml-1">Group</span>
//         </div>
//         <div className="text-[10px] text-muted-foreground mt-0.5 tracking-[0.3em] ">
//           Event Management
//         </div>
//       </div>

//       {/* Profile avatar */}
//       <div className="flex items-center gap-3 px-6 py-4 border-b border-border">
//         <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-700 to-primary flex items-center justify-center flex-shrink-0">
//           <span
//             style={{ fontFamily: "'Cinzel', serif" }}
//             className="text-sm font-bold text-white"
//           >
//             AB
//           </span>
//         </div>
//         <div>
//           <div className="text-sm font-semibold text-foreground">abybaby_group</div>
//           <div className="text-xs text-muted-foreground">India's #1 BTL Agency</div>
//         </div>
//       </div>

//       {/* Navigation */}
//       <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
//         {NAV_ITEMS.map(({ id, label, Icon }) => (
//           <button
//             key={id}
//             onClick={() => navigate(id)}
//             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
//               currentPage === id
//                 ? "bg-primary/12 text-primary"
//                 : "text-foreground/55 hover:bg-white/5 hover:text-foreground"
//             }`}
//           >
//             <Icon
//               size={20}
//               className={`flex-shrink-0 transition-colors ${
//                 currentPage === id ? "text-primary" : "group-hover:text-foreground"
//               }`}
//             />
//             <span
//               style={{ fontFamily: "'Cinzel', serif" }}
//               className={`font-medium text-sm ${currentPage === id ? "text-primary" : ""}`}
//             >
//               {label}
//             </span>
//             {currentPage === id && (
//               <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
//             )}
//           </button>
//         ))}
//       </nav>

//       {/* Stats strip */}
//       <div className="px-6 py-3 border-t border-border grid grid-cols-3 gap-2 text-center">
//         {[
//           { val: "25+", lbl: "Years" },
//           { val: "5K+", lbl: "Projects" },
//           { val: "100+", lbl: "Clients" },
//         ].map(({ val, lbl }) => (
//           <div key={lbl}>
//             <div
//               style={{ fontFamily: "'Cinzel', serif" }}
//               className="text-base font-bold text-primary leading-tight"
//             >
//               {val}
//             </div>
//             <div className="text-[10px] text-muted-foreground">{lbl}</div>
//           </div>
//         ))}
//       </div>

//       {/* Socials + Contact */}
//       <div className="px-5 py-4 border-t border-border">
//         <div className="flex gap-2 mb-3">
//           {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
//             <button
//               key={i}
//               className="w-8 h-8 flex items-center justify-center text-foreground/35 hover:text-primary transition-colors duration-150"
//             >
//               <Icon size={15} />
//             </button>
//           ))}
//         </div>
//         <div className="flex items-center gap-2 text-foreground/45 text-[11px] mb-1.5">
//           <Phone size={11} className="text-primary flex-shrink-0" />
//           +91 98765 43210
//         </div>
//         <div className="flex items-center gap-2 text-foreground/45 text-[11px]">
//           <Mail size={11} className="text-primary flex-shrink-0" />
//           hello@abybabygroup.com
//         </div>
//       </div>
//     </aside>
//   );
// }
// import {
//   HardDrive as Instagram,
//   HardDrive as Facebook,
//   HardDrive as Twitter,
//   HardDrive as Youtube,
//   Phone,
//   Home,
//   Info,
//   Image,
//   Star,
//   BookOpen,
//   Mail,
// } from "lucide-react";

// const NAV_ITEMS = [
//   { id: "home", label: "Home", Icon: Home },
//   { id: "about", label: "About", Icon: Info },
//   { id: "gallery", label: "Gallery", Icon: Image },
//   { id: "festival", label: "Festival", Icon: Star },
//   { id: "blog", label: "Blog", Icon: BookOpen },
// ];

// export function DesktopSidebar({ currentPage, navigate }) {
//   return (
//     <aside className="hidden lg:flex fixed left-0 top-0 h-full w-[240px] bg-card border-r border-border flex-col z-40">
//       {/* Logo */}
//       <div
//         className="px-6 py-5 border-b border-border flex flex-row justify-center items-center gap-1 cursor-pointer"
//         onClick={() => navigate("home")}
//       >
//         <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-700 to-primary flex items-center justify-center flex-shrink-0">
//           <span
//             style={{ fontFamily: "'Cinzel', serif" }}
//             className="text-sm font-bold text-white"
//           >
//             AB
//           </span>
//         </div>
//         <div className="flex flex-col justify-center items-start">
//           <div
//             style={{ fontFamily: "'Cinzel', serif" }}
//             className="text-xl font-bold text-primary leading-tight"
//           >
//             AbyBaby
//             <span className="text-foreground/65 ml-1">Group</span>
//           </div>

//           <div className="text-[10px] text-muted-foreground mt-0.5 tracking-[0.3em] ">
//             Event Management
//           </div>
//         </div>
//       </div>

//       {/* Profile avatar */}
//       {/* <div className="flex items-center gap-3 px-6 py-4 border-b border-border"> */}
//       {/* <div>
//           <div className="text-sm font-semibold text-foreground">
//             abybaby_group
//           </div>

//           <div className="text-xs text-muted-foreground">
//             India's #1 BTL Agency
//           </div>
//         </div>*/}
//       {/* </div> */}

//       {/* Navigation */}
//       <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
//         {NAV_ITEMS.map(({ id, label, Icon }) => (
//           <button
//             key={id}
//             onClick={() => navigate(id)}
//             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
//               currentPage === id
//                 ? "bg-primary/12 text-primary"
//                 : "text-foreground/55 hover:bg-white/5 hover:text-foreground"
//             }`}
//           >
//             <Icon
//               size={20}
//               className={`flex-shrink-0 transition-colors ${
//                 currentPage === id
//                   ? "text-primary"
//                   : "group-hover:text-foreground"
//               }`}
//             />

//             <span
//               style={{ fontFamily: "'Cinzel', serif" }}
//               className={`font-medium text-sm ${
//                 currentPage === id ? "text-primary" : ""
//               }`}
//             >
//               {label}
//             </span>

//             {currentPage === id && (
//               <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
//             )}
//           </button>
//         ))}
//       </nav>

//       {/* Stats strip */}
//       <div className="px-6 py-3 border-t border-border grid grid-cols-3 gap-2 text-center">
//         {[
//           { val: "25+", lbl: "Years" },
//           { val: "5K+", lbl: "Projects" },
//           { val: "100+", lbl: "Clients" },
//         ].map(({ val, lbl }) => (
//           <div key={lbl}>
//             <div
//               style={{ fontFamily: "'Cinzel', serif" }}
//               className="text-base font-bold text-primary leading-tight"
//             >
//               {val}
//             </div>

//             <div className="text-[10px] text-muted-foreground">{lbl}</div>
//           </div>
//         ))}
//       </div>

//       {/* Socials + Contact */}
//       <div className="px-5 py-4 border-t border-border">
//         <div className="flex gap-2 mb-3">
//           {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
//             <button
//               key={i}
//               className="w-8 h-8 flex items-center justify-center text-foreground/35 hover:text-primary transition-colors duration-150"
//             >
//               <Icon size={15} />
//             </button>
//           ))}
//         </div>

//         <div className="flex items-center gap-2 text-foreground/45 text-[11px] mb-1.5">
//           <Phone size={11} className="text-primary flex-shrink-0" />
//           +91 98765 43210
//         </div>

//         <div className="flex items-center gap-2 text-foreground/45 text-[11px]">
//           <Mail size={11} className="text-primary flex-shrink-0" />
//           hello@abybabygroup.com
//         </div>
//       </div>
//     </aside>
//   );
// }
// import { useEffect, useRef, useState } from "react";
// import {
//   HardDrive as Instagram,
//   HardDrive as Facebook,
//   HardDrive as Twitter,
//   HardDrive as Youtube,
//   Phone,
//   Home,
//   Info,
//   Image,
//   Star,
//   BookOpen,
//   Mail,
// } from "lucide-react";

// const NAV_ITEMS = [
//   { id: "home", label: "Home", Icon: Home },
//   { id: "about", label: "About", Icon: Info },
//   { id: "gallery", label: "Gallery", Icon: Image },
//   { id: "festival", label: "Festival", Icon: Star },
//   { id: "blog", label: "Blog", Icon: BookOpen },
// ];

// // ─────────────────────────────────────────────────────────────────────────────
// // useCountUp
// // Animates a number from 0 → target over `duration` ms using requestAnimationFrame.
// // `suffix` (e.g. "+" or "K+") is appended to the displayed value.
// // ─────────────────────────────────────────────────────────────────────────────
// function useCountUp(target, duration = 1800, suffix = "") {
//   const [display, setDisplay] = useState("0" + suffix);
//   const rafRef = useRef(null);

//   useEffect(() => {
//     const startTime = performance.now();

//     // Parse numeric part — handles "25", "5000" (for "5K+"), "100"
//     const tick = (now) => {
//       const elapsed = now - startTime;
//       const progress = Math.min(elapsed / duration, 1);

//       // Ease-out cubic for a natural deceleration
//       const eased = 1 - Math.pow(1 - progress, 3);
//       const current = Math.round(eased * target);

//       // Format: compress thousands to "K" when target >= 1000
//       const formatted =
//         target >= 1000
//           ? (current / 1000).toFixed(current < 1000 ? 1 : 0) + "K"
//           : String(current);

//       setDisplay(formatted + suffix);

//       if (progress < 1) {
//         rafRef.current = requestAnimationFrame(tick);
//       }
//     };

//     rafRef.current = requestAnimationFrame(tick);
//     return () => cancelAnimationFrame(rafRef.current);
//   }, [target, duration, suffix]);

//   return display;
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // StatItem — individual animated stat
// // ─────────────────────────────────────────────────────────────────────────────
// function StatItem({ target, suffix, lbl, delay = 0 }) {
//   const [started, setStarted] = useState(false);

//   // Stagger start by delay ms so each counter starts slightly after the previous
//   useEffect(() => {
//     const t = setTimeout(() => setStarted(true), delay);
//     return () => clearTimeout(t);
//   }, [delay]);

//   const value = useCountUp(started ? target : 0, 1600, suffix);

//   return (
//     <div>
//       <div
//         style={{ fontFamily: "'Cinzel', serif" }}
//         className="text-base font-bold text-primary leading-tight tabular-nums"
//       >
//         {value}
//       </div>
//       <div className="text-[10px] text-muted-foreground">{lbl}</div>
//     </div>
//   );
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // STATS CONFIG
// // target → the raw number to count to
// // suffix → appended after the formatted number
// // ─────────────────────────────────────────────────────────────────────────────
// const STATS = [
//   { target: 25, suffix: "+", lbl: "Years" },
//   { target: 5000, suffix: "+", lbl: "Projects" },
//   { target: 100, suffix: "+", lbl: "Clients" },
// ];

// // ─────────────────────────────────────────────────────────────────────────────
// // DESKTOP SIDEBAR
// // ─────────────────────────────────────────────────────────────────────────────
// export function DesktopSidebar({ currentPage, navigate }) {
//   return (
//     <aside className="hidden lg:flex fixed left-0 top-0 h-full w-[240px] bg-card border-r border-border flex-col z-40 ">
//       {/* Logo — click navigates home */}
//       <div
//         className="px-6 py-5 border-b border-border flex flex-row justify-center items-center gap-1 cursor-pointer"
//         onClick={() => navigate("home")}
//       >
//         <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-700 to-primary flex items-center justify-center flex-shrink-0">
//           <span
//             style={{ fontFamily: "'Cinzel', serif" }}
//             className="text-sm font-bold text-white"
//           >
//             AB
//           </span>
//         </div>
//         <div className=" flex-col justify-center items-start ">
//           <div
//             style={{ fontFamily: "'Cinzel', serif" }}
//             className="text-xl font-bold text-primary leading-tight"
//           >
//             AbyBaby
//             <span className="text-foreground/65 ml-1">Group</span>
//           </div>
//           <div className="text-[10px] text-muted-foreground mt-0.5 tracking-[0.3em] uppercase">
//             Event Management
//           </div>
//         </div>
//       </div>

//       {/* Navigation */}
//       <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
//         {NAV_ITEMS.map(({ id, label, Icon }) => (
//           <button
//             key={id}
//             onClick={() => navigate(id)}
//             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
//               currentPage === id
//                 ? "bg-primary/12 text-primary"
//                 : "text-foreground/55 hover:bg-white/5 hover:text-foreground"
//             }`}
//           >
//             <Icon
//               size={20}
//               className={`flex-shrink-0 transition-colors ${
//                 currentPage === id
//                   ? "text-primary"
//                   : "group-hover:text-foreground"
//               }`}
//             />
//             <span
//               style={{ fontFamily: "'Cinzel', serif" }}
//               className={`font-medium text-sm ${currentPage === id ? "text-primary" : ""}`}
//             >
//               {label}
//             </span>
//             {currentPage === id && (
//               <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
//             )}
//           </button>
//         ))}
//       </nav>

//       {/* Animated stats strip */}
//       <div className="px-6 py-3 border-t border-border grid grid-cols-3 gap-2 text-center">
//         {STATS.map(({ target, suffix, lbl }, i) => (
//           <StatItem
//             key={lbl}
//             target={target}
//             suffix={suffix}
//             lbl={lbl}
//             delay={i * 120} // stagger: 0ms, 120ms, 240ms
//           />
//         ))}
//       </div>

//       {/* Socials + Contact */}
//       <div className="px-5 py-4 border-t border-border">
//         <div className="flex gap-2 mb-3">
//           {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
//             <button
//               key={i}
//               className="w-8 h-8 flex items-center justify-center text-foreground/35 hover:text-primary transition-colors duration-150"
//             >
//               <Icon size={15} />
//             </button>
//           ))}
//         </div>
//         <div className="flex items-center gap-2 text-foreground/45 text-[11px] mb-1.5">
//           <Phone size={11} className="text-primary flex-shrink-0" />
//           +91 98765 43210
//         </div>
//         <div className="flex items-center gap-2 text-foreground/45 text-[11px]">
//           <Mail size={11} className="text-primary flex-shrink-0" />
//           hello@abybabygroup.com
//         </div>
//       </div>
//     </aside>
//   );
// }
import { useEffect, useRef, useState } from "react";
import {
  HardDrive as Instagram,
  HardDrive as Facebook,
  HardDrive as Twitter,
  HardDrive as Youtube,
  Phone,
  Home,
  Info,
  Image,
  Star,
  BookOpen,
  Mail,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

const NAV_ITEMS = [
  { id: "home", label: "Home", Icon: Home },
  { id: "about", label: "About", Icon: Info },
  { id: "gallery", label: "Gallery", Icon: Image },
  { id: "festival", label: "Festival", Icon: Star },
  { id: "blog", label: "Blog", Icon: BookOpen },
];

// ─────────────────────────────────────────────────────────────────────────────
// useCountUp
// ─────────────────────────────────────────────────────────────────────────────
function useCountUp(target, duration = 1800, suffix = "") {
  const [display, setDisplay] = useState("0" + suffix);
  const rafRef = useRef(null);

  useEffect(() => {
    const startTime = performance.now();

    const tick = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);

      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(eased * target);

      const formatted =
        target >= 1000
          ? (current / 1000).toFixed(current < 1000 ? 1 : 0) + "K"
          : String(current);

      setDisplay(formatted + suffix);

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(tick);
      }
    };

    rafRef.current = requestAnimationFrame(tick);

    return () => cancelAnimationFrame(rafRef.current);
  }, [target, duration, suffix]);

  return display;
}

// ─────────────────────────────────────────────────────────────────────────────
// StatItem
// ─────────────────────────────────────────────────────────────────────────────
function StatItem({ target, suffix, lbl, delay = 0 }) {
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  const value = useCountUp(started ? target : 0, 1600, suffix);

  return (
    <div>
      <div
        style={{ fontFamily: "'Cinzel', serif" }}
        className="text-base font-bold text-primary leading-tight tabular-nums"
      >
        {value}
      </div>

      <div className="text-[10px] text-muted-foreground">{lbl}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STATS
// ─────────────────────────────────────────────────────────────────────────────
const STATS = [
  { target: 25, suffix: "+", lbl: "Years" },
  { target: 5000, suffix: "+", lbl: "Projects" },
  { target: 100, suffix: "+", lbl: "Clients" },
];

// ─────────────────────────────────────────────────────────────────────────────
// DESKTOP SIDEBAR
// ─────────────────────────────────────────────────────────────────────────────
export function DesktopSidebar({
  currentPage,
  navigate,
  collapsed,
  setCollapsed,
}) {
  // const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={`hidden lg:flex fixed left-0 top-0 h-full bg-card border-r border-border flex-col z-40 transition-all duration-300 ${
        collapsed ? "w-[88px]" : "w-[240px]"
      }`}
    >
      {/* Toggle Button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute right-0 top-[82px] translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full border border-border bg-card text-foreground shadow-md flex items-center justify-center hover:bg-primary hover:text-white transition-all duration-300 z-50"
      >
        {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
      </button>

      {/* Logo */}
      <div
        className={`px-4 py-5 border-b border-border flex items-center cursor-pointer transition-all duration-300 ${
          collapsed ? "justify-center" : "gap-3"
        }`}
        onClick={() => navigate("home")}
      >
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-lime-700 to-primary  flex items-center justify-center flex-shrink-0">
          <span
            style={{ fontFamily: "'Cinzel', serif" }}
            className="text-sm font-bold text-white"
          >
            AB
          </span>
        </div>

        {!collapsed && (
          <div>
            <div
              style={{ fontFamily: "'Cinzel', serif" }}
              className="text-xl font-bold text-primary leading-tight"
            >
              AbyBaby
              <span className="text-foreground/65 ml-1">Group</span>
            </div>

            <div className="text-[10px] text-muted-foreground mt-0.5 tracking-[0.3em] uppercase">
              Event Management
            </div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => navigate(id)}
            className={`w-full flex items-center rounded-xl transition-all duration-200 group ${
              collapsed ? "justify-center px-2 py-3" : "gap-3 px-4 py-3"
            } ${
              currentPage === id
                ? "bg-primary/12 text-primary"
                : "text-black hover:bg-white/5 hover:text-foreground"
            }`}
          >
            <Icon
              size={20}
              className={`flex-shrink-0 transition-colors ${
                currentPage === id
                  ? "text-primary"
                  : "group-hover:text-foreground"
              }`}
            />

            {!collapsed && (
              <>
                <span
                  style={{ fontFamily: "'Cinzel', serif" }}
                  className={`font-medium text-sm ${
                    currentPage === id ? "text-primary" : ""
                  }`}
                >
                  {label}
                </span>

                {currentPage === id && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                )}
              </>
            )}
          </button>
        ))}
      </nav>

      {/* Stats */}
      {!collapsed && (
        <div className="px-6 py-3 border-t border-border grid grid-cols-3 gap-2 text-center">
          {STATS.map(({ target, suffix, lbl }, i) => (
            <StatItem
              key={lbl}
              target={target}
              suffix={suffix}
              lbl={lbl}
              delay={i * 120}
            />
          ))}
        </div>
      )}

      {/* Social + Contact */}
      <div
        className={`px-4 py-4 border-t border-border transition-all duration-300 ${
          collapsed ? "flex flex-col items-center" : ""
        }`}
      >
        <div
          className={`flex gap-2 ${
            collapsed ? "flex-col items-center" : "mb-3"
          }`}
        >
          {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
            <button
              key={i}
              className="w-8 h-8 flex items-center justify-center text-foreground/35 hover:text-primary transition-colors duration-150"
            >
              <Icon size={15} />
            </button>
          ))}
        </div>

        {!collapsed && (
          <>
            <div className="flex items-center gap-2 text-foreground/45 text-[11px] mb-1.5">
              <Phone size={11} className="text-primary flex-shrink-0" />
              +91 98765 43210
            </div>

            <div className="flex items-center gap-2 text-foreground/45 text-[11px]">
              <Mail size={11} className="text-primary flex-shrink-0" />
              hello@abybabygroup.com
            </div>
          </>
        )}
      </div>
    </aside>
  );
}
